vertx.eventBus().send("the_test", "pass")
